figure;
ch1 = readmatrix('F0004CH1.CSV');
ch1 = ch1(:,4:5);
ch2 = readmatrix('F0004CH2.CSV');
ch2 = ch2(:,4:5);

offset = -1.082e-5;

plot_nicely(ch2(:,1) - offset,ch2(:,2), ch1(:,1) - offset,ch1(:,2));
box on;