function plot_nicely(X, Y, Xprime, Yprime)

Y = smoothdata(Y, 1, "movmean", 7);
Yprime = smoothdata(Yprime, "gaussian", 11);

hold on;
yyaxis left;
ylabel('DAC SPI CS [V]');
ylim([-0.2, 3.5]);
plot( 1e6 * X,Y);

yyaxis right;
ylabel('DAC Channel output [V]');
plot(1e6 * Xprime,Yprime);
lgd = legend(["DAC SPI CS", "DAC Channel output"]);
lgd.Location = "northwest";
xlabel("time [\mus]")

xlim([-2, 21 ]);
ylim([-0.2, 3.5]);
hold off;
end
