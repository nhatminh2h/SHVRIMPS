ch1 = readmatrix('F0004CH1.CSV');
ch1 = ch1(:,4:5);
ch2 = readmatrix('F0004CH2.CSV');
ch2 = ch2(:,4:5);

plot(ch1(:,1),ch1(:,2));
hold on;
plot(ch2(:,1),ch2(:,2));
hold off;

f2 = figure;

ch1 = readmatrix('F0005CH1.CSV');
ch1 = ch1(:,4:5);
ch2 = readmatrix('F0005CH2.CSV');
ch2 = ch2(:,4:5);

plot(ch1(:,1),ch1(:,2));
hold on;
plot(ch2(:,1),ch2(:,2));
hold off;

f3 = figure;

ch1 = readmatrix('F0006CH1.CSV');
ch1 = ch1(:,4:5);
ch2 = readmatrix('F0006CH2.CSV');
ch2 = ch2(:,4:5);

plot(ch1(:,1),ch1(:,2));
hold on;
plot(ch2(:,1),ch2(:,2));
hold off;




