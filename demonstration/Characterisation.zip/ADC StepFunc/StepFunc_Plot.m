T100 = readmatrix('StepFunc_e100us.csv');
x = linspace(1,height(T100),height(T100));

diff_T100 = diff(T100);
x = linspace(1,height(T100),height(T100));
xx = x;
xx(length(xx)) = [];
hold on;

[m100,I100]=max(diff_T100);


% Threshold

T10 = readmatrix('StepFunc_e10us.csv');
diff_T10 = diff(T10);
[m10,i10] = max(diff_T10);

x = linspace(1,height(T10),height(T10));

Th = 10;
x = [];
Th_low = i10 - Th;
Th_high = i10+Th;

x = 1:1:2*Th +1;
T10 = T10(Th_low:Th_high);
plot(x,T10);






