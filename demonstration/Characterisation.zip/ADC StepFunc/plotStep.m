function plotStep(a, Th, offset)
a = a*2.95/32768+0.08;
StepDiff = diff(a);
[m,i] = max(StepDiff);
x = [];
Th_low = i - Th + offset;
Th_high = i+Th +offset;

x = 1:1:2*Th +1;
len = 2*Th+1;
x = linspace(0,len*172,len);

a = a(Th_low:Th_high);
plot(x,a);

xlabel('Time(\mus)');
ylabel('Voltage [V]');
end