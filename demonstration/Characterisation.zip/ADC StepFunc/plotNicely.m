function plotNicely(X, Y, Xprime, Yprime)

Y = smoothdata(Y, 1, "movmedian", 17);
Yprime = smoothdata(Yprime, "movmean", 21);

hold on;
yyaxis left;
ylabel('Control signal from the DAC [V]');
plot(X,Y);

yyaxis right;
ylabel('High Voltage Output [V]');
plot(Xprime,Yprime);

%title("High voltage response to step function");
%lgd = legend(["input", "response"]);
%lgd.Location = "northwest";
xlabel("time [s]")
hold off;
end