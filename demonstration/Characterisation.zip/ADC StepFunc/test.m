figure;
threshold = 3;

hold on;
% T100 = readmatrix('StepFunc_e100us.csv');
% plotStep(T100, threshold);
% 
% T10 = readmatrix('StepFunc_e10us.csv');
% plotStep(T10, threshold);
% 
% T1 = readmatrix('StepFunc_e1us.csv');
% T1 = T1(:,1);
% plotStep(T1, threshold);

T0 = readmatrix('StepFunc_e0us.csv');
T0 = T0(:,3);
plotStep(T0, threshold, 0);



line([400 400 1200],[0 3.3 3.3], 'color', 'r');
legend('ADC Voltage Readings','Step Function')
xlim([0 1200]);
grid on;
box on;

%  ch2 = readmatrix('F0002CH2.CSV');
%  ch2 = ch2(:,5);
%  
%  Th = threshold*200/(10^(-4));
%  offset = 0;
%  
%  StepDiff = diff(ch2);
%  [m,i] = max(StepDiff);
%  Th_low = i - Th + offset;
%  Th_high = i + Th +offset;
%  
%  len = 2*Th+1;
%  x = linspace(0,len*10^(-4),len);
%  
%  ch2 = ch2(Th_low:Th_high);
%  plot(x,ch2,'Marker','o');

%legend('100 us','10 us','1 us','0 us');