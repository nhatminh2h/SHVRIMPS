d=[];
m = readmatrix('TEK0001.CSV');%2.2
d(:,:,1) = m(:,4:5);

m = readmatrix('TEK0003.CSV');%4.7
d(:,:,2) = m(:,4:5);
% m = readmatrix('TEK0004.CSV');
% d(:,:,4) = m(:,4:5);
% m = readmatrix('TEK0005.CSV');
% d(:,:,5) = m(:,4:5);
m = readmatrix('TEK0006.CSV');%6.8
d(:,:,3) = m(:,4:5);
m = readmatrix('TEK0007.CSV');%10
d(:,:,4) = m(:,4:5);
% m = readmatrix('TEK0008.CSV');
% d(:,:,8) = m(:,4:5);
m = readmatrix('TEK0009.CSV');%20
d(:,:,5) = m(:,4:5);
% m = readmatrix('TEK0010.CSV');
% d(:,:,10) = m(:,4:5);
m = readmatrix('TEK0011.CSV');%open
d(:,:,6) = m(:,4:5);

m = readmatrix('TEK0004.CSV');
d(:,:,8) = m(:,4:5);

hold on;

for c = 1:6
    d(:,2,c) = smoothdata(d(:,2,c), 1, "movmean",3);
    plot(d(:,1,c)*1000+14,d(:,2,c)*1666.6666666666667);
end
ylabel('HV Module Output [V]');

yline([100+0.9*900 100+0.1*900]);
yline(100+0.707*900);


yyaxis right;
d(:,2,8) = smoothdata(d(:,2,8), 1, "movmedian",5);
plot(d(:,1,8)*1000+14,d(:,2,8));
ylabel('DAC Input Signal [V]');


xlim([0 110]);

legend('2.2 M\Omega','4.7 M\Omega','6.8 M\Omega','10 M\Omega','20 M\Omega', ...
    'Open Circuit','DAC Signal');
xlabel('Time [ms]');


hold off;