m= [];
m = [
2.2	8.48	13.04
4.7	6.92	8.72
6.8	9.16	8.52
10	15.72	8.04
20	29.92	9.6
60  56      5.9];

m(:,4) = 350/m(:,3);
m(:,5) = 350/m(:,2);

err = [1 1 1 1 1 1];

figure;

errorbar(m(:,1),m(:,3),err);

ylabel('Response Time [ms]');
%ylim([0 31]);
hold on;

errorbar(m(:,1),m(:,2),err);

xlabel('Load Resistance [M\Omega]');
grid on;


legend('Rise Time','Fall Time');

%ylim([0 31]);