ch1 = readmatrix('F0007CH2.CSV');
ch1 = ch1(:,4:5);
ch2 = readmatrix('F0007CH1.CSV');
ch2 = ch2(:,4:5);
plotNicely(ch1(:,1),ch1(:,2), ch2(:,1),2000 * ch2(:,2));

