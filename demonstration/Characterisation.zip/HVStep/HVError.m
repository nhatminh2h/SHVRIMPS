voltage = [];
time = [];
figure;
DAC2HVer = [-459.8735126
-373.7019715
-346.6381452
-275.9657297
-279.0537223
-220.6709259
-214.63284
-132.7210734
8.046927119
35.22207881
56.70776678
64.82421649
44.54203426
38.99897756
38.75264846
-0.238744665];
DAC2HVPE = [-0.03065823417
-0.02669299797
-0.02666447271
-0.02299714414
-0.02536852021
-0.02206709259
-0.02384809333
-0.01659013418
0.001149561017
0.005870346468
0.01134155336
0.01620605412
0.01484734475
0.01949948878
0.03875264846
Inf];

hold on;
opts.Range = '7,2';
ch = flip([1 2 4 7 8 10 12 20 16 19 23 24 27 28 31 33]);
setVoltage= 15000:-1000:0;
i = 1;


filePattern = fullfile( '*.CSV'); % Change to whatever pattern you need.
theFiles = dir(filePattern);

for k = ch
    baseFileName = theFiles(k).name;
    fullFileName = fullfile(theFiles(k).folder, baseFileName);

    fprintf(1, 'Now reading %s\n', fullFileName);
    m = readmatrix(fullFileName);
    m = m(:,4:5);
    
    indexupper = find(m==0.03);%look up index for time = 0.03
    indexlower = find(m==0.17);%look up index for time = 0.17
    %find mean of voltage value between t=0.03 and t=0.17
    meanvoltage(i) = mean(m(indexupper:indexlower,2));
    voltageerror(i) = meanvoltage(i)*1900 - setVoltage(i);
    voltageerrorper(i) = voltageerror(i)/setVoltage(i)*100;
    
    i= i+1;
end

yyaxis left;
plot(setVoltage,voltageerror);
%plot(setVoltage,DAC2HVer);
ylabel('Error [V]');
%ylim([0 250]);
yyaxis right;
plot(setVoltage,voltageerrorper);
%plot(setVoltage,DAC2HVPE*100);
ylabel('Error Percentage [%]');
%ylim([0 14]);
grid on;


xlabel('Voltage [V]');

hold off;

box on;

%legend('HV output vs intended voltage','HV output vs amplified DAC','HV output vs intended voltage','HV output vs amplified DAC');


%legend('15000','14000','13000','12000','11000','9000','8000','7000','6000','5000','4000','3000','2000','1000','0');
