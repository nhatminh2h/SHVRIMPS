m = [1000	5.9	56
2000	7	67
3000	7.6	75
4000	8	76
5000	7.5	80
6000	7.6	81
7000	7.8	75
8000	7.2	75
9000	8.1	78
10000	8	77
11000	8.4	79.2
12000	8.2	77
13000	7.7	75
14000	8	77.2
15000	8	78.4];


err(1:15) = 1;

figure;
errorbar(m(:,1),m(:,3),err,'LineStyle','-');

ylabel('Response Time [ms]');
%ylim([0 35]);
hold on;

errorbar(m(:,1),m(:,2),err,'LineStyle','-');

xlabel('Voltage [V]');
grid on;
xlim([0 15000]);

legend('Fall Time','Rise Time');
title('60 M\Omega Load Impedance');

