val = 10500;
voltage = [];
time = [];
figure;
hold on;
opts.Range = '7,2';
ch = flip([1 2 4 7 8 10 12 20 16 19 23 24 27 28 31 33]);


filePattern = fullfile( '*.CSV'); % Change to whatever pattern you need.
theFiles = dir(filePattern);

for k = ch
    baseFileName = theFiles(k).name;
    fullFileName = fullfile(theFiles(k).folder, baseFileName);

    fprintf(1, 'Now reading %s\n', fullFileName);
    m = readmatrix(fullFileName);

    time(:,k) =  (m(:,4));
    voltage(:,k) = (m(:,5));

    plot(time(:,k),voltage(:,k)*1920);
    xlabel('Voltage [V]');
    ylabel('Error [V]');
end

xlim([-0.05 0.4]);

hold off;


legend('15000','14000','13000','12000','11000','10000','9000','8000','7000','6000','5000','4000','3000','2000','1000','0');
