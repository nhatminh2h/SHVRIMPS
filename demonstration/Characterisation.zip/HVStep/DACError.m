val = 10500;
voltage = [];
time = [];
figure;
hold on;
opts.Range = '7,2';
ch = flip([3 5 6 9 11 13 21 17 18 22 25 26 29 32 34]);
setVoltage= linspace(3.3,0,16);
i = 0;


filePattern = fullfile( '*.CSV'); % Change to whatever pattern you need.
theFiles = dir(filePattern);

for k = ch
    i= i+1;
    baseFileName = theFiles(k).name;
    fullFileName = fullfile(theFiles(k).folder, baseFileName);

    fprintf(1, 'Now reading %s\n', fullFileName);
    m = readmatrix(fullFileName);
    m = m(:,4:5);
    
    indexupper = find(m==0.03);%look up index for time = 0.03
    indexlower = find(m==0.17);%look up index for time = 0.17
    %find mean of voltage value between t=0.03 and t=0.17
    meanvoltage(i) = mean(m(indexupper:indexlower,2));
    voltageerror(i) = meanvoltage(i) - setVoltage(i);
    voltageerrorper(i) = voltageerror(i)/setVoltage(i)*100;
end

voltageerror(i+1) = 0;
voltageerrorper(i+1) = inf;

yyaxis left;
plot(setVoltage,voltageerror*1000);
ylabel('Error [mV]');
%ylim([0 250]);
yyaxis right;
plot(setVoltage,voltageerrorper);
ylabel('Error Percentage [%]');
xlim([0 3.3]);
grid on;

xlabel('Voltage [V]');

hold off;

box on;
%legend('15000','14000','13000','12000','11000','10000','9000','8000','7000','6000','5000','4000','3000','2000','1000','0');
