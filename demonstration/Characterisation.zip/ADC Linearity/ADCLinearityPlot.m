m = readmatrix('ADCLinearity.csv');
voltage = m(2:34,2:11);
voltage = voltage *3.152/32768;
setvoltage = m(1,2:11);

voltageerror = voltage - setvoltage;
voltagemin = min(voltageerror);
voltagemax = max(voltageerror);
voltageerrormean = mean(voltageerror);
%voltageerror = voltage - voltagemean;
%voltagemin = min(voltageerror);
%voltagemax = max(voltageerror);

%voltagemin = abs(voltagemin);
%voltagecombine = [voltagemax; voltagemin];
%voltageerror = max(voltagecombine)*1000;


figure;
errorbar(setvoltage,voltageerrormean*1000, voltagemin*1000, voltagemax*1000);
%plot(setvoltage,voltageerrormean*1000);
ylabel('ADC Error[mV]');
xlabel('Input Voltage[V]');
xline(3.3,'--',{'3.3 V'});
hold on;

yyaxis right
voltageerrorper = (voltageerrormean./setvoltage)*100;
plot(setvoltage, voltageerrorper);
ylabel('ADC Mean Error Percentage(%)');

grid on;



% voltageminper = (voltagemin/voltagemean)*100;
% voltagemaxper = (voltagemax/voltagemean)*100;

% errorbar(setvoltage,voltagemean,voltagemin, voltagemax);
% ylabel('ADC Voltage Reading Adjusted[V]');
% xlabel('Input Voltage[V]');
% 
% ylim([-0.1 4.2])