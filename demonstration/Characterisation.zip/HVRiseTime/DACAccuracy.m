m = readmatrix('varying_voltage/TEK0005.CSV');% original signal
input2000V = m(671:1046,4:5);
avg = input2000V();

m = readmatrix('varying_voltage/TEK0007.CSV');% original signal
input3000V = m(671:1046,4:5);

m = readmatrix('varying_voltage/TEK0010.CSV');% original signal
input4000V = m(671:1046,4:5);

m = readmatrix('varying_voltage/TEK0013.CSV');% original signal
input5000V = m(671:1046,4:5);

hold on;

%plot(input2000V(:,1),input2000V(:,2));
%plot(input3000V(:,1),input3000V(:,2));
%plot(input4000V(:,1),input4000V(:,2));
%plot(input5000V(:,1),input5000V(:,2));



m = readmatrix('varying_voltage/TEK0021.CSV');% original signal
input6000V = m(630:1257,4:5);

m = readmatrix('varying_voltage/TEK0023.CSV');% original signal
input7000V = m(630:1257,4:5);

m = readmatrix('varying_voltage/TEK0025.CSV');% original signal
input8000V = m(630:1257,4:5);

m = readmatrix('varying_voltage/TEK0026.CSV');% original signal
input9000V = m(630:1257,4:5);

%plot(input6000V(:,1),input6000V(:,2));
%plot(input7000V(:,1),input7000V(:,2));
%plot(input8000V(:,1),input8000V(:,2));
%plot(input9000V(:,1),input9000V(:,2));


figure;

n = [2 3 4 5 6 7 8 9];

n1 = n*3.3*1000/15000;

error = [mean(input2000V(:,2))-n1(:,1) mean(input3000V(:,2))-n1(:,2) ...
    mean(input4000V(:,2))-n1(:,3) mean(input5000V(:,2))-n1(:,4) ...
    mean(input6000V(:,2))-n1(:,5) mean(input7000V(:,2))-n1(:,6)...
    mean(input8000V(:,2))-n1(:,7) mean(input9000V(:,2))-n1(:,8)];


errorR = error./n1;

%yline(n1);
yyaxis left;
plot(n1, 1000*error,'Marker','o');
ylabel('Error [mV]');

yyaxis right;
plot(n1, 100*errorR, 'Marker','o');

xlabel('Set Voltage [V]');
ylabel('Relative Error [%]');

grid on;




%xlim([0.02 0.035]);




