figure;

m = readmatrix('varying_voltage/TEK0005.CSV');% original signal
input2000V = m(:,4:5);

m = readmatrix('varying_voltage/TEK0004.CSV');%2.2
output2000V = m(:,4:5);
hold on

yyaxis left
input2000V (:,2) = smoothdata(input2000V(:,2), "movmedian", 1.5);
plot(1000 * input2000V (:, 1),  0.5* input2000V (:, 2),"-", "LineWidth", 2);
ylabel("DAC Input Signal [V]", "FontSize", 20);

yyaxis right;

output2000V (:,2) = smoothdata (output2000V(:,2), "movmean", 17);
plot(1000 * output2000V (:, 1), 5250 * output2000V (:, 2),"-", "LineWidth", 2);

ylabel("High Voltage Output [V]", "FontSize", 20);
xlabel("Time [ms]", "FontSize", 20);

xlim=([-7 94]);

%legend(["Input Signal", '10 M\Omega  2kV'], "FontSize", 14);

for i=1:numel(datsInp)
    yyaxis left 
    nexttile
    hold on
    dataToPlot = datsInp{i};
    dataToPlot(:,2) = smoothdata(dataToPlot(:,2), "movmedian", 1.5);
    plot(1000 * dataToPlot(:, 1), dataToPlot(:, 2),"-", "LineWidth", 1.5);
       
    ylim([0, 2.5]);
    set(gca,'FontSize',15);

    
    yyaxis right;
    ylim([0, 10000]);

    dataToPlot = datsOut{i};
    dataToPlot(:,2) = smoothdata(dataToPlot(:,2), "movmean", 17);
    plot(1000 * dataToPlot(:, 1), 5250 * dataToPlot(:, 2),"-", "LineWidth", 1.5);
    
    s = "load=10M\Omega ";
    s = s + outputLevels(i) +" HV output";
    legend(["Input Signal",s], "FontSize", 14);
    ylabel("High Voltage Output [V]", "FontSize", 15);
    xlabel("Time [ms]", "FontSize", 15);
    grid on;
    hold off
end