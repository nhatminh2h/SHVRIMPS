m= [];
m = [
2000	5	15
3000	5.4	18
4000	5.2	16.6
5000	5.5	18];

%m(:,4) = 350/m(:,3);
%m(:,5) = 350/m(:,2);

err = [1 1 1 1];

figure;
subplot(2,2,1);
errorbar(m(:,1),m(:,3),err,'Marker','o','LineStyle','--');

ylabel('Response Time [ms]');
ylim([0 35]);
hold on;

errorbar(m(:,1),m(:,2),err,'Marker','o','LineStyle','--');

xlabel('Voltage [V]');
grid on;

legend('Fall Time','Rise Time');
title('10 M\Omega Load Impedance');

%ylim([0 31]);

subplot(2,2,2)

m= [];
m = [
6000	5	28
7000	5	30
8000	5	28
9000	5	28];


err = [1 1 1 1];
errorbar(m(:,1),m(:,3),err,'Marker','o','LineStyle','--');
hold on;
errorbar(m(:,1),m(:,2),err,'Marker','o','LineStyle','--');

%ylabel('Response Time [ms]');
ylim([0 35]);

xlabel('Voltage [V]');
grid on;

legend('Fall Time','Rise Time');
title('20 M\Omega Load Impedance');

subplot(2,2,3);