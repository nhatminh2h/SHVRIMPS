val = 10500;


m = readmatrix('varying_voltage/TEK0004.CSV');
output2000V = m(671:1046,5);
o2000mean = mean(output2000V)*val;

m = readmatrix('varying_voltage/TEK0006.CSV');
output3000V = m(671:1046,5);
o3000mean = mean(output3000V)*val;

m = readmatrix('varying_voltage/TEK0008.CSV');
output4000V = m(671:1046,5);
o4000mean = mean(output4000V)*val;

m = readmatrix('varying_voltage/TEK0012.CSV');
output5000V = m(671:1046,5);
o5000mean = mean(output5000V)*val;

x = [3000, 4000, 5000];
y = [o2000mean, o3000mean, o4000mean, o5000mean];
y_diff = diff(y);

plot(x,y_diff);
xlabel('Voltage [V]');
ylabel('Error [V]');

hold on;

m = readmatrix('varying_voltage/TEK0017.CSV');%2.2
output2000V = m(630:1257,5);
o2000mean = mean(output2000V)*val;

m = readmatrix('varying_voltage/TEK0020.CSV');%4.7
output3000V = m(630:1257,5);
o3000mean = mean(output3000V)*val;

m = readmatrix('varying_voltage/TEK0022.CSV');%6.8
output4000V = m(630:1257,5);
o4000mean = mean(output4000V)*val;

m = readmatrix('varying_voltage/TEK0024.CSV');%10
output5000V = m(630:1257,5);
o5000mean = mean(output5000V)*val;

m = readmatrix('varying_voltage/TEK0027.CSV');%10
output6000V = m(630:1257,5);
o6000mean = mean(output6000V)*val;

x=[];
y=[];

x = [6000, 7000, 8000, 9000];
y = [o2000mean, o3000mean, o4000mean, o5000mean, o6000mean];
y_diff = diff(y);

plot(x,y_diff);
xlabel('Voltage [V]');
ylabel('Difference from the previous voltage [V]');

hold off;

legend('10 M\Omega Load Resistance', '20 M\Omega Load Resistance');


